package org.aisen.weibo.sina.ui.fragment.base;

import com.m.ui.fragment.AFragmentHelper;

public class FragmentHelper extends AFragmentHelper {

}
