package org.sina.android.bean;

import java.io.Serializable;

public class GroupSortResult implements Serializable {

	private static final long serialVersionUID = 4765685604463050569L;

	private String result;

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}
	
}
